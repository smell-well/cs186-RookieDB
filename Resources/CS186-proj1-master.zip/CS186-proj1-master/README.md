# Project 1: SQL

This is my implementation for CS186 project1: SQL. You can find the project specification [here](https://github.com/PKUFlyingPig/CS186/blob/master/project-handout/proj1/getting-started.md) and other learning materials for CS186 [here](https://github.com/PKUFlyingPig/CS186).



